package com.piphorror.mod.entity;

import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.UUID;

public class PipEntity extends PathfinderMob implements GeoEntity {
    public static final String STATE_STALK = "idle_stalk";
    public static final String STATE_LOOKOUT_LISTEN = "lookout_listen";
    public static final String STATE_PROWL_WALK = "prowl_walk";
    public static final String STATE_PEEK = "peek_corner";
    public static final String STATE_HUNT = "crawl_hunt";
    public static final String STATE_FAKE_IGNORE = "fake_ignore_stare";
    public static final String STATE_SUMMON = "event_summon";

    private static final EntityDataAccessor<String> AI_STATE =
        SynchedEntityData.defineId(PipEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Boolean> IS_FAKE_PIP =
        SynchedEntityData.defineId(PipEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> LISTEN_TICKS =
        SynchedEntityData.defineId(PipEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> EVENT_TICKS =
        SynchedEntityData.defineId(PipEntity.class, EntityDataSerializers.INT);

    private final AnimatableInstanceCache geoCache = GeckoLibUtil.createInstanceCache(this);
    private UUID listeningTargetUuid;

    private static final RawAnimation ANIM_LOOKOUT_LISTEN =
        RawAnimation.begin().thenLoop("animation.pip.lookout_listen");
    private static final RawAnimation ANIM_IDLE_STALK =
        RawAnimation.begin().thenLoop("animation.pip.idle_stalk");
    private static final RawAnimation ANIM_PROWL_WALK =
        RawAnimation.begin().thenLoop("animation.pip.prowl_walk");
    private static final RawAnimation ANIM_PEEK_CORNER =
        RawAnimation.begin().thenLoop("animation.pip.peek_corner");
    private static final RawAnimation ANIM_CRAWL_HUNT =
        RawAnimation.begin().thenLoop("animation.pip.crawl_hunt");
    private static final RawAnimation ANIM_FAKE_IGNORE =
        RawAnimation.begin().thenLoop("animation.pip.fake_ignore_stare");
    private static final RawAnimation ANIM_EVENT_SUMMON =
        RawAnimation.begin().thenPlay("animation.pip.event_summon");

    public PipEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
            .add(Attributes.MAX_HEALTH, 80.0D)
            .add(Attributes.MOVEMENT_SPEED, 0.34D)
            .add(Attributes.ATTACK_DAMAGE, 7.0D)
            .add(Attributes.FOLLOW_RANGE, 48.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(AI_STATE, STATE_STALK);
        this.entityData.define(IS_FAKE_PIP, false);
        this.entityData.define(LISTEN_TICKS, 0);
        this.entityData.define(EVENT_TICKS, 0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new LookAtPlayerGoal(this, Player.class, 24.0F));
        this.goalSelector.addGoal(5, new RandomStrollGoal(this, 0.65D) {
            @Override
            public boolean canUse() {
                return !isListening() && super.canUse();
            }
        });
    }

    public String getAiState() {
        return this.entityData.get(AI_STATE);
    }

    public void setAiState(String state) {
        this.entityData.set(AI_STATE, state);
    }

    public boolean isFakePip() {
        return this.entityData.get(IS_FAKE_PIP);
    }

    public void setFakePip(boolean fake) {
        this.entityData.set(IS_FAKE_PIP, fake);
    }

    public boolean isListening() {
        return !isFakePip() && (this.entityData.get(LISTEN_TICKS) > 0 || STATE_LOOKOUT_LISTEN.equals(getAiState()));
    }

    /**
     * Real Pip freezes on 4 legs and raises its front-right paw beside its twitching ear.
     * Fake/Scary Pip refuses to listen, snaps its head sideways, and unhinges its jaw.
     *
     * @return true if this Pip actually listened; false if it is a Fake/Scary Pip that ignored the call.
     */
    public boolean startLookoutListen(ServerPlayer speaker, int ticks) {
        this.getNavigation().stop();
        if (speaker != null) {
            this.getLookControl().setLookAt(speaker, 45.0F, 45.0F);
        }

        if (this.isFakePip()) {
            this.entityData.set(LISTEN_TICKS, 0);
            this.entityData.set(EVENT_TICKS, ticks);
            this.setAiState(STATE_FAKE_IGNORE);
            this.playSound(SoundEvents.ENDERMAN_STARE, 0.85F, 0.55F);
            return false;
        }

        this.listeningTargetUuid = speaker != null ? speaker.getUUID() : null;
        this.entityData.set(LISTEN_TICKS, ticks);
        this.setAiState(STATE_LOOKOUT_LISTEN);
        this.playSound(SoundEvents.CAT_AMBIENT, 0.75F, 0.62F);
        return true;
    }

    public void triggerTimedState(String state, int ticks) {
        this.entityData.set(LISTEN_TICKS, 0);
        this.entityData.set(EVENT_TICKS, ticks);
        this.setAiState(state);
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide) {
            int listenTicks = this.entityData.get(LISTEN_TICKS);
            if (listenTicks > 0) {
                this.getNavigation().stop();
                if (this.listeningTargetUuid != null) {
                    Player speaker = this.level().getPlayerByUUID(this.listeningTargetUuid);
                    if (speaker != null) {
                        this.getLookControl().setLookAt(speaker, 35.0F, 35.0F);
                    }
                }
                this.entityData.set(LISTEN_TICKS, listenTicks - 1);
                if (listenTicks - 1 <= 0 && STATE_LOOKOUT_LISTEN.equals(getAiState())) {
                    this.setAiState(STATE_STALK);
                    this.listeningTargetUuid = null;
                }
            }

            int eventTicks = this.entityData.get(EVENT_TICKS);
            if (eventTicks > 0) {
                this.entityData.set(EVENT_TICKS, eventTicks - 1);
                if (eventTicks - 1 <= 0 && !isListening()) {
                    this.setAiState(STATE_STALK);
                }
            }
        }
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "pip_main_controller", 4, state -> {
            String aiState = getAiState();
            return switch (aiState) {
                case STATE_LOOKOUT_LISTEN -> state.setAndContinue(ANIM_LOOKOUT_LISTEN);
                case STATE_PROWL_WALK -> state.setAndContinue(ANIM_PROWL_WALK);
                case STATE_PEEK -> state.setAndContinue(ANIM_PEEK_CORNER);
                case STATE_HUNT -> state.setAndContinue(ANIM_CRAWL_HUNT);
                case STATE_FAKE_IGNORE -> state.setAndContinue(ANIM_FAKE_IGNORE);
                case STATE_SUMMON -> state.setAndContinue(ANIM_EVENT_SUMMON);
                default -> {
                    if (state.isMoving()) {
                        state.setAndContinue(ANIM_PROWL_WALK);
                    } else {
                        state.setAndContinue(ANIM_IDLE_STALK);
                    }
                    yield PlayState.CONTINUE;
                }
            };
        }));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.geoCache;
    }
}
