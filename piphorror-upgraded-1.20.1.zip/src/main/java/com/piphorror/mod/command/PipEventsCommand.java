package com.piphorror.mod.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.piphorror.mod.ai.PipEventDirector;
import com.piphorror.mod.entity.PipEntity;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Comparator;
import java.util.List;

@Mod.EventBusSubscriber(modid = "piphorror", bus = Mod.EventBusSubscriber.Bus.FORGE)
public class PipEventsCommand {
    private static final List<String> EVENT_KEYS = List.of("lights_flicker", "stalk_behind", "door_knock", "mimic_whisper", "hunt_escalation", "hallucination_decoy");
    private static final List<String> STATE_KEYS = List.of(
        PipEntity.STATE_STALK,
        PipEntity.STATE_LOOKOUT_LISTEN,
        PipEntity.STATE_PROWL_WALK,
        PipEntity.STATE_PEEK,
        PipEntity.STATE_HUNT,
        PipEntity.STATE_FAKE_IGNORE,
        PipEntity.STATE_SUMMON
    );
    private static final List<String> VARIANT_KEYS = List.of("real", "fake");

    private static final SuggestionProvider<CommandSourceStack> EVENT_SUGGESTIONS =
        (ctx, builder) -> SharedSuggestionProvider.suggest(EVENT_KEYS, builder);
    private static final SuggestionProvider<CommandSourceStack> STATE_SUGGESTIONS =
        (ctx, builder) -> SharedSuggestionProvider.suggest(STATE_KEYS, builder);
    private static final SuggestionProvider<CommandSourceStack> VARIANT_SUGGESTIONS =
        (ctx, builder) -> SharedSuggestionProvider.suggest(VARIANT_KEYS, builder);

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();

        dispatcher.register(Commands.literal("pip")
            .requires(src -> src.hasPermission(2))
            .then(Commands.literal("listen")
                .executes(ctx -> triggerListen(ctx.getSource(), ctx.getSource().getPlayerOrException()))
                .then(Commands.argument("target", EntityArgument.player())
                    .executes(ctx -> triggerListen(ctx.getSource(), EntityArgument.getPlayer(ctx, "target")))))
            .then(Commands.literal("event")
                .then(Commands.argument("event_id", StringArgumentType.word())
                    .suggests(EVENT_SUGGESTIONS)
                    .executes(ctx -> triggerEvent(
                        ctx.getSource(),
                        StringArgumentType.getString(ctx, "event_id"),
                        ctx.getSource().getPlayerOrException()
                    ))
                    .then(Commands.argument("target", EntityArgument.player())
                        .executes(ctx -> triggerEvent(
                            ctx.getSource(),
                            StringArgumentType.getString(ctx, "event_id"),
                            EntityArgument.getPlayer(ctx, "target")
                        )))))
            .then(Commands.literal("state")
                .then(Commands.argument("ai_state", StringArgumentType.word())
                    .suggests(STATE_SUGGESTIONS)
                    .executes(ctx -> setState(
                        ctx.getSource(),
                        StringArgumentType.getString(ctx, "ai_state")
                    ))))
            .then(Commands.literal("variant")
                .then(Commands.argument("kind", StringArgumentType.word())
                    .suggests(VARIANT_SUGGESTIONS)
                    .executes(ctx -> setVariant(
                        ctx.getSource(),
                        StringArgumentType.getString(ctx, "kind")
                    ))))
        );
    }

    private static int triggerListen(CommandSourceStack source, ServerPlayer target) {
        ServerLevel level = source.getLevel();
        PipEntity pip = findNearestPip(level, target);
        if (pip == null) {
            source.sendFailure(Component.literal("No Pip entity found within 64 blocks."));
            return 0;
        }
        boolean listened = pip.startLookoutListen(target, 120);
        if (!listened) {
            source.sendSuccess(() -> Component.literal("Nearest entity is Fake/Scary Pip and refused to listen!"), true);
            return 1;
        }
        source.sendSuccess(() -> Component.literal("Real Pip entered 4-legged Lookout listen pose for " + target.getName().getString()), true);
        return 1;
    }

    private static int triggerEvent(CommandSourceStack source, String eventId, ServerPlayer target) {
        ServerLevel level = source.getLevel();
        PipEntity pip = findNearestPip(level, target);
        if (pip == null) {
            source.sendFailure(Component.literal("No Pip entity found within 64 blocks."));
            return 0;
        }
        boolean ok = PipEventDirector.executeEvent(level, target, pip, eventId);
        if (!ok) {
            source.sendFailure(Component.literal("Unknown Pip event: " + eventId));
            return 0;
        }
        source.sendSuccess(() -> Component.literal("Executed Pip event: " + eventId), true);
        return 1;
    }

    private static int setState(CommandSourceStack source, String aiState) {
        ServerLevel level = source.getLevel();
        ServerPlayer player = source.getPlayer();
        if (player == null) return 0;
        PipEntity pip = findNearestPip(level, player);
        if (pip == null) {
            source.sendFailure(Component.literal("No Pip entity found nearby."));
            return 0;
        }
        pip.triggerTimedState(aiState, 160);
        source.sendSuccess(() -> Component.literal("Set Pip animation/AI state to " + aiState), true);
        return 1;
    }

    private static int setVariant(CommandSourceStack source, String kind) {
        ServerLevel level = source.getLevel();
        ServerPlayer player = source.getPlayer();
        if (player == null) return 0;
        PipEntity pip = findNearestPip(level, player);
        if (pip == null) {
            source.sendFailure(Component.literal("No Pip entity found nearby."));
            return 0;
        }
        boolean fake = "fake".equalsIgnoreCase(kind);
        pip.setFakePip(fake);
        source.sendSuccess(() -> Component.literal("Set nearest Pip variant to " + (fake ? "FAKE/SCARY (won't listen)" : "REAL (listens on 4 legs)")), true);
        return 1;
    }

    private static PipEntity findNearestPip(ServerLevel level, ServerPlayer player) {
        return level.getEntitiesOfClass(PipEntity.class, player.getBoundingBox().inflate(64.0D))
            .stream()
            .min(Comparator.comparingDouble(p -> p.distanceToSqr(player)))
            .orElse(null);
    }
}
