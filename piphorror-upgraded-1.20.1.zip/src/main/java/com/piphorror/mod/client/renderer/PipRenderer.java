package com.piphorror.mod.client.renderer;

import com.piphorror.mod.PipHorrorMod;
import com.piphorror.mod.client.model.PipModel;
import com.piphorror.mod.entity.PipEntity;
import com.piphorror.mod.init.ModEntities;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

@Mod.EventBusSubscriber(modid = PipHorrorMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class PipRenderer extends GeoEntityRenderer<PipEntity> {
    public PipRenderer(EntityRendererProvider.Context context) {
        super(context, new PipModel());
        this.shadowRadius = 0.55F;
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.PIP.get(), PipRenderer::new);
    }
}
