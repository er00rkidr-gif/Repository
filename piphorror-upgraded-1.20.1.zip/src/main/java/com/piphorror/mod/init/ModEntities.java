package com.piphorror.mod.init;

import com.piphorror.mod.PipHorrorMod;
import com.piphorror.mod.entity.PipEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
        DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, PipHorrorMod.MOD_ID);

    public static final RegistryObject<EntityType<PipEntity>> PIP = ENTITIES.register(
        "pip",
        () -> EntityType.Builder.of(PipEntity::new, MobCategory.MONSTER)
            .sized(0.75F, 0.95F)
            .build(new ResourceLocation(PipHorrorMod.MOD_ID, "pip").toString())
    );
}
